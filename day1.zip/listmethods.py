alist = [10,45,32,56,21,54,90,1]


alist.append(100)   # adding single object to the list
print("After appneding :", alist)

#adding multiple values
alist.extend([21,65,89])
print('After extending',alist)

# alist.insert(index,value)
alist.insert(1,300)
print('After inserting',alist)

# list.pop(index) - value at that index will be removed
alist.pop(1)
print('Afte pop', alist)

alist.pop()
print('Afte pop', alist)



#alist.remove(540)
print('after removing', alist)

if 540 in alist:
    alist.remove(540)
else:
    print(540,'doesnt exist')  
    
    
    
alist.reverse()
print('after reversing', alist)


alist.sort()
print('After sorting', alist)

alist.sort(reverse= True)
print('After sorting', alist)





print('Index of the value 45 is :',alist.index((45)))

print("100 is been repeated for ",alist.count(100), "times")







# for loop
for val in alist:
    print(val)



name = "python"
for char in name:
    print(char)


## c style
for index in range(0,len(alist)):
    print(alist[index])
























