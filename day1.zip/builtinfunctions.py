




print(10,2030)

print(list(range(1,10,2)))
print(tuple(range(1,10,2)))


# In python2.7   raw_input()
# In python3.x   input()

name = input('Enter any name :')
print(name)


alist = [10,20,30]
print(type(alist))


print(isinstance(alist,list))
print(isinstance(alist,str))
print(isinstance(alist,tuple))



if isinstance(alist,list):
    alist.append(50)


print(max(alist))
print(min(alist))

print(sum(alist))



fobj = open("notes.txt")
print(fobj.read())


