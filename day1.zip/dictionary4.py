

ytag = {
  "kind": "youtube#searchListResponse",
  "etag": "m2yskBQFythfE4irbTIeOgYYfBU1",
  "nextPageToken": "CAUQAA",
  "regionCode": "KE",
  "pageInfo": {
    "totalResults": 4249,
    "resultsPerPage": 5
  },
  "items": [
    {
      "kind": "youtube#searchResult",
      "etag": "m2yskBQFythfE4irbTIeOgYYfBU2",
      "id": {
        "kind": "youtube#channel",
        "channelId": "UCJowOS1R0FnhipXVqEnYU1A"
      }
    },
    {
      "kind": "youtube#searchResult",
      "etag": "m2yskBQFythfE4irbTIeOgYYfBU3",
      "id": {
        "kind": "youtube#video",
        "videoId": "Eqa2nAAhHN0"
      }
    },
    {
      "kind": "youtube#searchResult",
      "etag": "m2yskBQFythfE4irbTIeOgYYfB4",
      "id": {
        "kind": "youtube#video",
        "videoId": "IirngItQuVs"
      }
    }
  ]
}


for key,value in ytag.items():
    if key == "etag" and isinstance(value,str):
        print(ytag['etag'])
    elif isinstance(value,list):
        for item in value:
            if "etag" in item:
                print(item['etag'])
