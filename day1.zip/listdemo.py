



alist = [10,45,32,56,21,54,90,1]


#list slicing
print(alist[0:5])
print(alist[::-1])


alist[0] = 1000
print("After replacing", alist)


atup = (12,23,43,45)

atup[0] = 10000
print("After replacing :", atup)




name = "python"
name[0] = "z"
print(name)














atup = (12,23,43,45)

# converting from tuple to list
alist = list(atup)
# making changes
alist.append(90)
# converting from list to tuple
atup = tuple(alist)
# dipslay
print("After manipulating", atup)




alist = [10,10,20,30,40,40]
print(set(alist))

















