


book = {"chap1": 10 ,"chap2": 20 ,"chap3":30}

print(book)

## display invidual values
print(book["chap1"])
print(book["chap2"])

# add new key:value pair
book["chap4"] = 40
book["chap5"] = 50
book["chap1"] = 1000
print(book)

# display Keys
print(book.keys())

# display values
print(book.values())


# display key:value
print(book.items())



#print(book["chap10"])

print(book.get("chap10"))  # None
print(book.get("chap1"))   # 10


if "chap10" in book:
    print(book["chap10"])
else:
    print("key doesnt exist")



newbook = {"chap8":80 ,"chap9":90}
book.update(newbook)
print(book)



book.pop("chap1")   # key and corresponding value will be removed
print(book)


print(book)


# combine dictionaries
finalbook = {**book,**newbook}
print(finalbook)




## display only keys
for key in book.keys():
    print(key)


for key in book:
    print(key)


# display values
for value in book.values():
    print(value)



# display key:value
for key,value in book.items():
    print(key,value)

























