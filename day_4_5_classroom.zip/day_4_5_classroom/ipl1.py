
#write a program to display all the unique countries from the file

import csv
countryset = set()
with open('IPL.csv','r') as fobj:
    header = fobj.readline()
    #convert file object to csv object
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        #print(line[3])
        countryset.add(line[3])
    # display the output
    for country in countryset:
        print(country)
        
        
import csv
countrydict = dict()
with open('IPL.csv','r') as fobj:
    header = fobj.readline()
    #convert file object to csv object
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        #print(line[3])
        country = line[3]
        countrydict[country] =1
    # display the output
    for country in countrydict.keys():
        print(country)        
        
        



import csv
countrylist = []
with open('IPL.csv','r') as fobj:
    header = fobj.readline()
    #convert file object to csv object
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        #print(line[3])
        country = line[3]
        if country not in countrylist:
            countrylist.append(country)
    for country in countrylist:
        print(country)