


import os
os.


noOfFiles = 0
noOfDir = 0
files = []
dirs = []
print("****Files*****")
for file in os.listdir():
    if os.path.isfile(file) :
        files.append(file)
    elif os.path.isdir(file):
        dirs.append(file)
print("***** Files *****")
for file in files:
    print(file)
print("total no of files", len(files))
print()
print()
print("***** Directories *****")
for file in dirs:
    print(file)
print("total no of files", len(dirs))





print("Printing .py files only") 
filepath=r"D:\trainings\jpmc16052022\programs" 
print(filepath)
for file in os.listdir(filepath):
    if ".py" in file:
        print(file)
        file_size=os.path.getsize(file)