
import requests

# web scraping
import bs4
from bs4 import BeautifulSoup

response = requests.get('https://www.google.com/')

#print(response.text)

# converting response string to soup object
soup = BeautifulSoup(response.text, 'html.parser')


print(soup.title)
print(soup.title.name)

print(soup.title.string)

for link in soup.find_all('a'):
    print(link.get('href'))
    
    
    
    