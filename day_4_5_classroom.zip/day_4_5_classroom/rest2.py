


import requests
import json

url = "https://api.github.com/"
username = "giridhar276"
token = "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"

endpoint = "gists"

finalurl = url + endpoint


with open("IPL.csv","r") as fobj:
    mydata = fobj.read()
    print(mydata)
    
payload = {
    "description": "rest api example",
    "public" : "true",
    'user' : username,
    "files" :{
                "IPL.csv" :{
                    "content":mydata
                    }   

        }
    }


response = requests.post(finalurl,data = json.dumps(payload) , auth=(username,token) )

print(response)


