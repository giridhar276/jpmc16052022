

import csv

class FileOutput:
    def __init__(self,file):
        self.file = file
    def displayOutput(self):
        with open(self.file,"r") as fobj:
            self.reader = csv.reader(fobj)
            for line in self.reader:
                print(line)

# always True

if __name__ =="__main__":
    f1= FileOutput("realestate.csv")
    f1.displayOutput()

    f2= FileOutput("IPL.csv")
    f2.displayOutput()






import csv
with open("realestate.csv","r") as fobj:
    reader = csv.reader(fobj)
    for line in reader:
        print(line)