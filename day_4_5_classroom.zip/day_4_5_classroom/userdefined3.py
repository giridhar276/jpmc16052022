



# keyword arguments
def display(c,a,b):
    print(a,b,c)
    
print(display(a= 10,b= 20,c = 30))




# if any object is prefixed with ** , it becomes dict
# variable length arguments
def display(**data):
    print(data)
display(a= 10,b= 20,c = 30)




# if any object is prefixed with * , it becomes tuple
def display(*args):
    #print(args)
    for val in args:
        print(val)

display(10,20,30,40)










