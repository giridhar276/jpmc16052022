

################################
class Employee:
    def displayEmployee(self,name):
        self.name = name
    def processInfo(self):
        print(self.name)

    


## object creation
emp1 = Employee()
emp1.displayEmployee('ram')
emp1.processInfo()


emp2 = Employee()
emp2.displayEmployee('gita')
emp1.processInfo()

emp3 = Employee()
emp3.displayEmployee('rao')
emp1.processInfo()
################################        



def displayEmployee():
    print("employee name :","ram")
displayEmployee()    











class Employee:
    def getEmployee(self,name):
        self.name = name
    def displayEmployee(self):
        print("Employee name :",self.name)
    
## object creation
emp1 = Employee()
emp1.getEmployee("ram")
emp1.displayEmployee()

## object creation
emp2 = Employee()
emp2.getEmployee("rao")
emp2.displayEmployee()

 
## object creation
emp3 = Employee()
emp3.getEmployee("rita")
emp3.displayEmployee()

 
    