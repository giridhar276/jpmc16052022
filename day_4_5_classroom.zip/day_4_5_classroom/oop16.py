


from bike import Bike

mybike = Bike(description='Pulsar',condition='OK',sale_price=500,cost=100)

mybike.service(cost = 30, new_sale_price=600)

print(mybike.sale_price)

print(mybike.sell())

