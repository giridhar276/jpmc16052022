

from flask import Flask

app = Flask(__name__)

@app.route("/")
def hello_world1():
    return "<p>Hello, World!</p>"

@app.route("/data")
def hello_world2():
    return "<p>this is data page</p>"

@app.route("/technologies")
def hello_world3():
    return "<p>this is technology page</p>"


app.run()