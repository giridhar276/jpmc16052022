




import pymysql
import csv

class dbConn:
        
        def __init__(self, host, port, user, password, database):
            # self.host = host
            # self.port = port
            # self.user = user
            # self.password = password
            # self.database = database
            db = pymysql.connect(host = host,port = port,user = user,password = password,database = database)
            #cursor = db.cursor()
            if db:
                print("Connection Success")

    
d = dbConn('127.0.0.1',3306,'root','india@123','jpmc')
