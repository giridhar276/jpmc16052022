
######## to delete all the gists

import requests
import json

url = "https://api.github.com/"
username = "giridhar276"
token = "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"

endpoint = "gists"

finalurl = url + endpoint


response_gists = requests.get(finalurl,auth = (username,token))


info = json.loads(response_gists.text)
for item in info:
    print(item['id'])
    url = finalurl  + "/" +  item['id']
    r = requests.delete(url,auth = (username,token))
    print(r.text)
    print("----------------------")