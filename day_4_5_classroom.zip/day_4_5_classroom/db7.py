
#write a program to write all the records from the database table to 18_May_2022.csv


import pymysql
import csv
import time
filename = time.strftime("realestate_%d_%b_%Y.csv")
print(filename)
try:
    db = pymysql.connect(host = '127.0.0.1',port=3306,user='root',password='india@123')
    cursor = db.cursor()
    if db:
        print("Connection successful")
        query = "select * from jpmc.realestate"
        cursor.execute(query)
        with open(filename,"w",newline = '') as fw:
            writer = csv.writer(fw)
            for record in cursor.fetchall():
                writer.writerow(record)
            
        db.close()
    else:
        print("connection failed")
    
except pymysql.err.OperationalError as err:
    print(err)        
except pymysql.err.IntegrityError as err:
    print(err)
    
except Exception as err:
    print(err)
    