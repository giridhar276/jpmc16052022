


import pymysql
import sys
import csv
import os
class Database:
    def __init__(self,host,port,user,password,database):
        self.host =  host
        self.port = port
        self.user = user
        self.password = password
        self.database = database
    
    def connect(self):
        # connect
        self.db = pymysql.connect(host = self.host,port=self.port,user=self.user,password=self.password,database = self.database)
        print(self.db)
        self.cursor = self.db.cursor()
    
    def insert(self,filename):
        try:
            self.filename = filename
            if os.path.isfile(self.filename) and os.path.getsize(self.filename) > 0:
                with open(self.filename,"r") as fobj:
                    self.reader = csv.reader(fobj)
                    for line in self.reader:
                        query="insert into jpmc.realestate values('{}', '{}')".format(line[0],line[1])
                        self.cursor.execute(query)                
                    
                self.db.commit()
                self.db.close()
            else:
                print("file doesn't exist")
        except Exception as err:
            print(err)
            print(sys.exc_info())



db1 = Database('127.0.0.1',3306,'root','india@123','jpmc')
db1.connect()
db1.insert('realestate.csv')

#db1.display()

















# import pymysql

# try:
#     db = pymysql.connect(host = '127.0.0.1',port=3306,user='root11',password='india@123')
#     print(db)
#     cursor = db.cursor()
#     if db:
#         print("Connection successful")
#         query = "insert into jpmc.realestate values('{}','{}')".format("Kondapur","Hyderabad")
#         cursor.execute(query)

#         db.commit()
        
        
#         query  = "select * from jpmc.realestate"
#         cursor.execute(query)
#         for record in cursor.fetchall():
#             print("street :", record[0])
#             print('City   :', record[1])
#             print("---------")  
#         db.close()
#     else:
#         print("Unable to connect")
    
# except pymysql.err.OperationalError as err:
#     print(err)        
# except pymysql.err.IntegrityError as err:
#     print(err)
    
# except Exception as err:
#     print(err)
