


def display(a,b):
    c  = a + b
    return c


total = display(10,20)
print(total)


# anonymous function or nameless function
# lambda is single liner function
#Instead of writing function body... we define lambda function
# expression gets replaced in the calling function
#functionname = lambda variables:expression

display = lambda a,b: a + b
total = display(10,20)
print(total)



display = lambda a,b: a + b
print(display(10,20))






# write a program to display the below output
alist = [10,20,30,40]

#Output :[15,25,35,45]

def increment(x):
    return x + 5
print(list(map(increment,alist)))




alist = [10,20,30,40]
increment = lambda x : x + 5
print(list(map(increment,alist)))


alist = [10,20,30,40]
print(list(map(lambda x : x + 5,alist)))



lang = ["google","oracle","tcs"]
# ["https://google.com","https://www.oracle.com"]
template = "https://www.{}.com"
print(list(map(lambda x: template.format(x) , lang)))




alist = [10,20,30,40]
#add =
blist=list() 
for i in alist:
    blist.append(i+5)
print(blist)



output = [val + 5 for val in alist]
print(output)




output = ['1','2','3','4']

print(list(map(lambda x: int(x) ,output)))





def totest(x):
    if x > 10 and x < 20 :
        return True
    else:
        return False

print(totest(12))








totest = lambda x: True if ( x > 10 and x < 20) else False
print(totest(12))
print(totest(30))


check = lambda x:  x > 10 and x < 20
print(check(12))
print(check(30))

























