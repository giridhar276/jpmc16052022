

import time
import pymysql
import csv
start = time.time()
try:
    mydata = []
    db = pymysql.connect(host = '127.0.0.1',port=3306,user='root',password='india@123')
    cursor = db.cursor()
    if db:
        print("Connection successful")
        query = "insert into jpmc.realestate values('{}','{}')"
        with open("realestate.csv") as fobj:
            reader = csv.reader(fobj)
            for line in reader:
                cursor.execute(query.format(line[0],line[1]))
                
        db.commit()      
            
    else:
        print("connection failed")
        
    end = time.time( ) 
    print ( "executemany method time:" , end - start ,  "sec" )
    
except Exception as err:
    print(err)
    
    
    
    


import pymysql
import csv
start = time.time()
try:
    mydata = []
    db = pymysql.connect(host = '127.0.0.1',port=3306,user='root',password='india@123')
    cursor = db.cursor()
    if db:
        print("Connection successful")
        query = "insert into jpmc.realestate values('{}','{}')"
        #query = "insert into jpmc.realestate(street,city) values(%s,%s)"
        with open("realestate.csv") as fobj:
            reader = csv.reader(fobj)
            for line in reader:
                mydata.append(tuple([line[0],line[1]]))
            #print(mydata)
        cursor.executemany(query,mydata)
        db.commit()      
            
    else:
        print("connection failed")
        
    end = time.time( ) 
    print ( "executemany method time:" , end - start ,  "sec" )
    
except Exception as err:
    print(err)    