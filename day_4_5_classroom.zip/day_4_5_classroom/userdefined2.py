


# default

def display(a =0,b = 0,c = None):
    print(a,b,c)



display()
display(10)
display(10,20)
display(10,20)











