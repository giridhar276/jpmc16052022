

import csv
player = dict()
with open('IPL.csv','r') as fobj:
    header = fobj.readline()
    #convert file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        player[line[1]] = int(line[14])
print(player)
        
    
