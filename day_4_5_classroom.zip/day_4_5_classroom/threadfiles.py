import csv
import time

start = time.time()

with open("realestate.csv") as fobj:
    reader  = csv.reader(fobj)
    for line in reader:
        print(line)
        
with open("IPL.csv") as fobj:
    reader  = csv.reader(fobj)
    for line in reader:
        print(line)        
        
end = time.time()

print("Total time :", end-start)
        
















import time
import threading

def readfile(filename):
    with open(filename) as fobj:
        reader  = csv.reader(fobj)
        for line in reader:
            print(line)        
    

        

t = time.time()

thread1 = threading.Thread(target=readfile,args = ("realestate.csv",))
thread2 = threading.Thread(target=readfile,args = ("IPL.csv",))
#threads.append(mythread)
#time.sleep(2)
thread1.start()
thread2.start()

thread1.join()
thread2.join()

print("Done in ", time.time() - t)
print("Done! Program ended")





