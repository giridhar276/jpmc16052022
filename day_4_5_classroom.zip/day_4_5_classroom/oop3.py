
# constructor :  __init__
# constructor will be invoked automatically when the object is created or instantiated


class Employee:
    # invoked automaticaly when object gets created
    def __init__(self,name,age,address):
        self.name = name
        self.age = age
        self.address = address
        
    
    def processInfo(self):
        print(self.name)
        print(self.age)
        print(self.address)
        

## object creation
emp1 = Employee('ram',25,"Hyderabad")
emp1.processInfo()



emp2 = Employee('rita',25,"delhi")
emp2.processInfo()


















