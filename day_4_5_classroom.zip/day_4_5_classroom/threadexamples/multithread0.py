


import time



def cal_square(numbers):
    print("calculate square numbers")
    for n in numbers:
        time.sleep(0.2)
        print("square :", n* n)
    
    
def cal_cube(numbers):
    print("calculate cube of numbers")
    for n in numbers:
        time.sleep(0.2)
        print("Cub3 : ", n*n*n)
        
        
arr = [2,3,8,9]


t = time.time()

cal_square(arr)
cal_cube(arr)


print("Done in ", time.time() - t)