import time
import threading

def cal_square(numbers):
    print("calculate square numbers")
    for n in numbers:
        time.sleep(0.2)
        print("square :", n* n)
    
    
def cal_cube(numbers):
    print("calculate cube of numbers")
    for n in numbers:
        time.sleep(0.2)
        print("Cub3 : ", n*n*n)
        


t = time.time()
arr = [2,3,8,9]
#t = time.time()
# creating threads
thread1 = threading.Thread(target=cal_square,args = (arr,))
thread2 = threading.Thread(target=cal_cube,args = (arr,))


thread1.start()
thread2.start()

# waiting for all the threads
thread1.join()
thread2.join()

print("Done in ", time.time() - t)
print("Done! Program ended")
        
