
class A:
    
    def __init__(self):
        self.__priv = "I am private"
        self._prot = "I am protected"
        self.pub = "I am public"
        print(self.__priv)        



obj = A()


print(obj.pub)
print(obj._prot)
print(obj.__priv)


