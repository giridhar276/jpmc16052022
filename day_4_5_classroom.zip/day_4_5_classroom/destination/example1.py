
'''
Write a Python program to display the below IP addresses

192.168.0.1
192.168.0.2
192.168.0.3
..
..
192.168.0.10
'''



fixed = '192.168.0.'

for val in range(1,11):
    print(fixed + str(val))



for val in range(1,11):
    print(fixed ,val,sep="")
    
    

    
ip = "192.168.0.{}"
for val in range(1,11):
    print(ip.format(val))
    
    
    
    
    
alist=["192.168.0.{}","192.168.1.{}"]

for clist in alist:
    for i in range(1,11):
        print(clist.format(i))
    
    
    
    
    
fixed = "192.168."
for val in range(0,2):
    ip = fixed + str(val)
    for val in range(1,11):
        print(ip +"." +  str(val))
    
    
    
    
    
#1 22 333 4444 55555 666666 7777777 88888888 999999999

for val in range(1,10):
    print(val * str(val) , end = " ")    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    