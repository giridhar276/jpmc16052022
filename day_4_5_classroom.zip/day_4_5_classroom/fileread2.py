

import csv
import sys
try:
    with open('languages.txt','r') as fobj:
        #convert file object to csv object
        reader = csv.reader(fobj)
        for line in reader:
            print(line)
    book = {"chap1":10}
    print(book["chap100"])
except FileNotFoundError as err :
    print(err)
    print("file not found")
except TypeError as err:
    print(err)
    print("Invalid operation")
except (IndexError,ValueError) as err:
    print(err)
    print("Invalid input or invalid index")
except Exception as err:
    print(err)
    print(sys.exc_info())
    print("some other error")
    
print("regular program")



    
    
    
    
    