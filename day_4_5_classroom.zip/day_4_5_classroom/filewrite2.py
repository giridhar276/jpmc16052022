# traditional way  # generic way

#fobj = open(r"D:\new\new\customers.txt","w")   # raw string
#fobj = open("D:/new/new/customers.txt","w")
fobj = open("D:\\new\\new\\customers1.txt","w")
fobj.write('tcs\n')
fobj.write('accenture\n')
fobj.close()


# pythonic way
# context manager
# line starts with keyword 'with'
# closing the file is not required using the context manager
# file will be closed automatically
with open("D:\\new\\new\\customers1.txt","w") as fobj:
    fobj.write('wipro\n')
    fobj.write('jpmc\n')

    
    
    
    








    

    