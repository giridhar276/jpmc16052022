



class Employee:
    def getEmployee(self,name,age,address):
        self.name = name
        self.age = age
        self.address = address
        
    
    def processInfo(self):
        print(self.name)
        print(self.age)
        self.age = self.age + 5
        print(self.address)
        print(self.age)


## object creation
emp1 = Employee()
emp1.getEmployee('ram',25,"Hyderabad")
emp1.processInfo()



emp2 = Employee()
emp2.getEmployee('rita',25,"delhi")
emp2.processInfo()











class Employee:
    def displayEmployee(self,name,age,address):
        self.name = name
        self.age = age
        self.address = address
    def processInfo(self,name,age,address):
        print(name)
        print(age)
        print(address)

    


## object creation
emp1 = Employee()
emp1.displayEmployee('ram',25,"Hyderabad")
emp1.processInfo('ram',25,"Hyderabad")



emp2 = Employee()
emp2.displayEmployee('rita',25,"delhi")
emp2.processInfo('rita',25,"delhi")



































