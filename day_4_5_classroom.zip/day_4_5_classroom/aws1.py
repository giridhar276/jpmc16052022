import boto3


aws_mag_con_root=boto3.session.Session(profile_name="user30")
ec2 = aws_mag_con_root.resource('ec2')

print(ec2)


instances = ec2.create_instances(
        ImageId="ami-0aeb7c931a5a61206",
        MinCount=1,
        MaxCount=1,
        InstanceType="t2.micro"
    )


print(instances)