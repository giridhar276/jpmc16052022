


import pymysql
import csv
import time
from openpyxl import Workbook
wb = Workbook()
# grab the active worksheet
ws = wb.active


#filename = time.strftime("realestate_%d_%b_%Y.csv")
#print(filename)
try:
    db = pymysql.connect(host = '127.0.0.1',port=3306,user='root',password='india@123')
    cursor = db.cursor()
    
    if db:
        print("Connection successful")
        query = "select * from jpmc.realestate"
        cursor.execute(query)
        header = ["street","city"]
        ws.append(header)
        for record in cursor.fetchall():
            ws.append(record)
            
        db.close()
    else:
        print("connection failed")
    wb.save("realestate.xlsx")
    
except pymysql.err.OperationalError as err:
    print(err)        
except pymysql.err.IntegrityError as err:
    print(err)
    
except Exception as err:
    print(err)
    