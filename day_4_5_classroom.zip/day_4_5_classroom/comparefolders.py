

import filecmp

source = r"D:\trainings\jpmc16052022\programs\source"
destination = r"D:\trainings\jpmc16052022\programs\destination"


dcmp = filecmp.dircmp(source,destination)


print(dcmp.left)


print(dcmp.right)


# files common in both directories

print(dcmp.common)


# right side list
print(dcmp.right_list)

