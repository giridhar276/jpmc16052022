


with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if "python programming" in line :
            print(line)
            
            
            


import re


with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search(".ython",line):
            print(line)
            