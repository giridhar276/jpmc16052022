


import requests
import json

url = "https://api.github.com/"
username = "giridhar276"
password = "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"


endpoint = "users/"

finalurl = url + endpoint

response = requests.get(finalurl,auth= (username,password))


requests.post()

if response.status_code == 200 :
    #print(response.text)
    data = json.loads(response.text)
    #print(type(data))
    for key,value in data.items():
        print(key.ljust(20), ":",value)


