


import pymysql

try:
    db = pymysql.connect(host = '127.0.0.1',port=3306,user='root',password='india@123')
    cursor = db.cursor()
    if db:
        print("Connection successful")
        query = "select * from jpmc.realestate"
        cursor.execute(query)
        for record in cursor.fetchall():
            print("street :", record[0])
            print('City   :', record[1])
            print("---------")
        db.close()
    else:
        print("connection failed")
    
except pymysql.err.OperationalError as err:
    print(err)        
except pymysql.err.IntegrityError as err:
    print(err)
    
except Exception as err:
    print(err)
    
    
