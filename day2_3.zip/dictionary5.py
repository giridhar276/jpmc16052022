

import json


fobj = open("employee_multiple1.json","r")
# converting to the dictionary
data = json.load(fobj)


for key,value in data.items():
    for item in value:
        print(item)
        
        
        
for item in data['users']:
    for key,value in item.items():
        print(key.ljust(10),value)
        print()
        

for item in data['users']:
    print(item['userId'])
    print(item['lastName'])




book = {"chap1":10 }
for key,value in book.items():
    print(key,value)



