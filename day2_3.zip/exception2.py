

import csv
import sys

try:
    countrylist = []
    with open('IPL.csv','r') as fobj:
        header = fobj.readline()
        #convert file object to csv object
        reader = csv.reader(fobj)
        # processing
        for line in reader:
            #print(line[3])
            country = line[3]
            countrylist.append(country)
        
    alist = [10,20,30]
    print(alist[100])        
    
except FileNotFoundError as err :
    print(err)
    print("file not found")
except TypeError as err:
    print(err)
    print("Invalid operation")
except (IndexError,ValueError,FileExistsError) as err:
    print(err)
    print("Invalid input or invalid index")
except Exception as err:
    print(err)
    print(sys.exc_info())
    print("some other error")
else:    
    # display part
    for country in set(countrylist):
        print(country.ljust(10), countrylist.count(country),"players")
finally:
    print("this will be executed all the times")
    
print("regular program")

