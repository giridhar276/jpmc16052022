

#
# fobj acts as reference or pointer
with open('languages.txt','r') as fobj:
    for line in fobj:
        line = line.strip()
        print(line)
        
        
        
# using readlines()
with open('languages.txt','r') as fobj:
    print(fobj.readlines())        
    
    
    
with open('languages.txt','r') as fobj:
    for line in fobj.readlines():
        print(line)
        
        
# using readlines()
with open('languages.txt','r') as fobj:
    print(fobj.readlines()[2:4])           
    
    
    
    
# using read()
with open('languages.txt','r') as fobj:
    print(type(fobj))
    print(fobj.read())



# using csv library
import csv
with open('languages111.txt','r') as fobj:
    #convert file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print(line)
print("regular code")
    
    



# using pandas
import pandas
data = pandas.read_csv('languages.txt')
print(data)
























    