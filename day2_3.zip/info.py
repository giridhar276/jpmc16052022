
'''
Write a Python program to display the below information.

display the current user name
display current working directory
display Operating system name
display process id of your running program
display the current timestamp
display yesterday’s date
display tomorrow’s date
display all the environment variables that are existing ( line by line )
display the python executable path ( just like ‘which python3’ in Linux )
'''


import os
import platform
import datetime
import time




print(os.getlogin())

print(os.getcwd())

print(platform.platform())

print(platform.node())


print(os.getpid())


print(datetime.datetime.now())

today = datetime.datetime.today()
print(today)

yesterday = today -  datetime.timedelta(days=1)
print(yesterday)



tomorrow = today +  datetime.timedelta(days=1)
print(tomorrow)



import calendar
print(calendar.month(2022,2))



import os
for name,path in os.environ.items():
    print(name.ljust(10),path)






