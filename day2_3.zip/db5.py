

import os
import csv
import pymysql
import time

start = time.time()
try:
    count = 0
    db = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='india@123')
    cursor=db.cursor()
    if db:
        print("connection success!!")
        filename = 'realestate.csv'
        if os.path.isfile(filename) and os.path.getsize(filename) > 0:
            with open(filename,'r') as fobj:
                reader=csv.reader(fobj)
                for line in reader:
                    
                    query="insert into jpmc.realestate values('{}', '{}')".format(line[0],line[1])
                    cursor.execute(query)
                    count = count + 1
            db.commit()
            print(count,"records inserted")
        else:
            print("file doesn't exist or file is empty")
        db.close()
    else:
        print("connection failed!!")
        
except Exception as Err:
    print(Err)    
end = time.time()
print("total time taken :", end - start ,"seconds")





