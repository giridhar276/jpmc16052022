

## all the methods will be imported to the programspace
import math
print(math.tan(2))
print(math.floor(34.4))




import math as m
print(m.ceil(45.3))
print(m.log(2))



#method3
# importing required methods only
# . is not required here
from math import cos,tan,log
print(cos(3))
print(tan(3))

# builtin packages
#C:\Users\gsripath\anaconda3\Lib

# third party packages
#C:\Users\gsripath\anaconda3\Lib\site-packages





import os
print(os.listdir())

for file in os.listdir():
    #print(file)
    if file.endswith(".csv"):
        print(file)


import os
for file in os.listdir('./'):
    if ".py" in file:
        file_size = os.path.getsize(file)
        print(file.ljust(20),": ",file_size,"bytes")



import os
print(os.listdir())

for file in os.listdir():
    print(file.ljust(20), os.path.getsize(file),"bytes")
































