

def add(x, y=2):
    return x + y


def product(x, y=2):
    return x * y