

alist = [10,20,30]



blist = [40,50,40]