


fobj = open("customers.txt","w")
fobj.write('tcs\n')
fobj.write('accenture\n')
fobj.close()



fobj = open("numbers.txt","w")
for val in range(1,10):
    fobj.write(str(val) + "\n")
fobj.close()


alist = ["google","oracle","microsoft"]
fobj = open("info.txt","w")
for element in alist:
    fobj.write(element.upper() + "\n")
fobj.close()



alist = ["google","oracle","microsoft"]

fobj = open("infodata.txt","w")
fobj.writelines(alist)
fobj.close()










