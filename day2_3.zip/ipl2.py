

import csv
countrylist = []
with open('IPL.csv','r') as fobj:
    header = fobj.readline()
    #convert file object to csv object
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        #print(line[3])
        country = line[3]
        countrylist.append(country)
    
    for country in set(countrylist):
        print(country.ljust(10), countrylist.count(country),"players")
        
        
        
import csv
countrydict = dict()
with open('IPL.csv','r') as fobj:
    header = fobj.readline()
    #convert file object to csv object
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        #print(line[3])
        country = line[3]
        if country not in countrydict:
            countrydict[country] =1      
        else:
            countrydict[country]+=1
    # display the output
    for key,value in countrydict.items():
        print(key.ljust(10), value,"players")