

#write a program to replace IND with INDIA and write the output to IPL_backup.csv

import time

outputfile = time.strftime("%d%b%Y.csv")
print(outputfile)

with open("IPL.csv","r") as fr:
    with open(outputfile,"w") as fw:
        for line in fr:
            line = line.strip()
            line = line.replace("IND","INDIA")
            fw.write(line + "\n")
            
            



            
            


#replace IND with India
import csv
wobj= open(r"IPL_backup1.csv","w") 
totalruns = 0
runs = []
with open(r"IPL.csv","r") as fobj:
        header = fobj.readline()
        reader = csv.reader(fobj)
        for lines in reader:
            if lines[3] == "IND":  
                #print(lines[13])
                print(lines[3] , lines[1] , lines[13])
                #totalruns = totalruns +  int(lines[13])
                runs.append(int(lines[13]))

print(sum(runs))
            