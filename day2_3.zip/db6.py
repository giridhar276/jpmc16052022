


import os
import pymysql
import csv
import time
start = time.time()

try:
    mydata = []
    db = pymysql.connect(host = '127.0.0.1',port=3306,user='root',password='india@123')
    cursor = db.cursor()
    if db:
        print("Connection successful")
        #query = "insert into jpmc.realestate values('{}','{}')"
        query = "insert into jpmc.realestate(street,city) values(%s,%s)"
        filename = "realestate.csv"
        if os.path.isfile(filename) and os.path.getsize(filename) > 0:        
            with open(filename,"r") as fobj:
                header = fobj.readline()
                reader = csv.reader(fobj)
                for line in reader:
                    data = ( line[0] , line[1] )
                    data = list(map(lambda x : "HYD" + x , data ))
                    mydata.append(data)
                #print(mydata)
            cursor.executemany(query,mydata)
            db.commit() 
        else:
            print("file doesn't exist or file is empty")
            
    else:
        print("connection failed")
        
    end = time.time( ) 
    print ( "execution method time:" , end - start ,  "sec" )
    
except Exception as err:
    print(err)    
    
    
    