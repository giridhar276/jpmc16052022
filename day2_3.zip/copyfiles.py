

import os
import shutil

source = r"D:\trainings\jpmc16052022\programs\source"
destination = r"D:\trainings\jpmc16052022\programs\destination"

currentdir = os.getcwd()
os.chdir(source)
for file in os.listdir(source):
    shutil.copy( file,destination)
os.chdir(currentdir)



import os
for val in range(1,11):
    os.mkdir("dir" + str(val))
    
    
