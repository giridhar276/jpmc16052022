

import boto3
session = boto3.session.Session(profile_name = 'default')
iam_re = session.resource('iam')

'''
for each_user in iam_re.users.all():
    print(each_user.name)
'''

iam_cli = session.client('iam')
for user in iam_cli.list_users()['Users']:
    print(user['UserName'])