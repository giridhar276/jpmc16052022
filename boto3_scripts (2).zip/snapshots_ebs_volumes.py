


import boto3
from pprint import pprint


session = boto3.session.Session(profile_name = "user14")

ec2_client = session.client(service_name = "ec2" , region_name = "ap-south-1")

#pprint(ec2_client.describe_volumes()['Volumes'])
#['VolumeId']

for each_vol in ec2_client.describe_volumes()['Volumes']:
    pprint(each_vol['VolumeId'])
    
    
    
