

import boto3
iam_con_re=boto3.resource(service_name="iam",region_name="us-east-1")


print(iam_con_re.