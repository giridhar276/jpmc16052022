import boto3
from pprint import pprint
session = boto3.session.Session(profile_name = "user14")

ec2_client = session.client(service_name = "ec2" , region_name = "ap-south-1")

#pprint(ec2_client.describe_volumes()['Volumes'])
#['VolumeId']

list_of_volids  = []
paginator = ec2_client.get_paginator('describe_volumes')
f_prod_backup = {"Name":'tag:Prod' , "Values":["backup","Backup"] }
for each_page in paginator.paginate(Filters=[f_prod_backup]):
    for each_vol in each_page['Volumes']:
        list_of_volids.append(each_vol['VolumeId'])
    
print("The list of vol ids ", list_of_volids)

snapids = []
for eachvolid in list_of_volids:
    #print("Taking snap of {}".format(eachvolid))
    res = ec2_client.create_snapshot(
        Description = 'Taking snap with lambda and cw',
        VolumeId = eachvolid,
        TagSpecifications=[
        {
            'ResourceType': 'snapshot',
            'Tags': [
                {
                    'Key': 'Delete-on',
                    'Value': '90'
                },
            ]
        },
    ]
        )
    #pprint(res['SnapshotId'])
    snapids.append(res['SnapshotId'])
print(snapids)

waiter = ec2_client.get_waiter('snapshot_completed')
waiter.wait(SnapshotIds=snapids)

print( "Succssfully completed snaps for the volumes of {}".format(list_of_volids))







    