# -*- coding: utf-8 -*-
"""
Created on Mon Oct 25 11:28:41 2021

@author: gsripath
"""



import boto3


aws_mag_con_root=boto3.session.Session(profile_name="default")
ec2 = aws_mag_con_root.resource('ec2')

print(ec2)




instances = ec2.create_instances(
        ImageId="ami-041d6256ed0f2061c",
        MinCount=1,
        MaxCount=1,
        InstanceType="t2.micro"
    )


print(instances)
#print(instances["Instances"][0]["InstanceId"])