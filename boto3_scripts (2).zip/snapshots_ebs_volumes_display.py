



import boto3
from pprint import pprint


session = boto3.session.Session(profile_name = "user14")

ec2_client = session.client(service_name = "ec2" , region_name = "ap-south-1")

#pprint(ec2_client.describe_volumes()['Volumes'])
#['VolumeId']

list_of_volids  = []

f_prod_backup = {"Name":'tag:Prod' , "Values":["backup","Backup"] }
for each_vol in ec2_client.describe_volumes(Filters = [f_prod_backup])['Volumes']:
    list_of_volids.append(each_vol['VolumeId'])
    

print("The list of vol ids ", list_of_volids)